package bankApplication;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;
public class CreateAccount 
{
	static ArrayList arr = new ArrayList(); 
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static Scanner sc=new Scanner(System.in);
    static int pass_code;
    static long accno=675456324132l;                                  //675456324132l this account number is common for every statement
	static long panno;
    static String username;
//*******************************************************Adding Customer***********************************************************************
    static void addCustomer() throws Exception
	{
    	System.out.println("—- Enter Customer Data —-");
    	System.out.println("Enter Customer Name :");
    	String custname = br.readLine(); 
    	System.out.println("Enter Customer Address : ");
    	String address = br.readLine();
    	System.out.println("Enter Customer Account Number : ");
    	Long custAcc = Long.parseLong(br.readLine());                          // Converts string into long and stores int to BufferReader
    	System.out.println("Enter Customer Initial Balance :");
    	Long bal = Long.parseLong(br.readLine());

    	//it will create new customer by using entered values
    	CreateAccount c = new CreateAccount();
    	arr.add(c);														// it will put new customer into ArrayList so here we stored object in a ArrayList

    	System.out.println("New Customer Added Successfully");
    	System.out.println("Welcome to Bank Mr./Ms."+custname);
	}
//**********************************************************Creating Account****************************************************************
	public static void createAcc()												 // create account
    {
		
       System.out.println("Enter your name:- ");
       String name1=sc.next();
       System.out.println("Enter Your Mobile Number:- ");
       long mobno=sc.nextLong();
       System.out.println("Enter Your address:- ");
       String address=sc.next();
       System.out.println("Enter Your Adhaar Number:- ");
       long adharno=sc.nextLong();
       try
		{
    	   System.out.println("Enter Your Pan card number:- ");           
            panno=sc.nextLong();
		}
		catch(Exception e)
		{
			//handle the Arithmetic Exception
			System.out.println("Pan Card Number should be only number.\n Start Again and  please Enter Valid Numeric Panno");
		}
    
       System.out.println("Enter Your Branch:- ");
       String branch=sc.next();
       pin();
             System.out.print("Enter Unique UserName:");
       username = sc.next();
       System.out.println("New Customer Added Successfully");
       System.out.println("Welcome Mr./Ms."+name1);

       System.out.println("-------------------Thank you for choosing us.-------------------\n Your Account details are:- ");
       System.out.println("Name:- "+name1);
       System.out.println("Mobile no:- "+mobno);
       System.out.println("Address:- "+address);
       System.out.println("Adhaar Number:- "+adharno);
       System.out.println("Pan Number:- "+panno);
       System.out.println("--------------------------------");
   		System.out.println("Account Number is:- "+accno);
       System.out.println("Your PassCode is:- "+pass_code);
    }
//***********************************************************Pin validation*********************************************************************
	static void pin() 
	{
	
		 try
			{
				//code that may throws exception
	    	   System.out.print("Enter New Password:");
	           pass_code = sc.nextInt();
	           for(int i=1;i<=1000;i++)
	           {
	           if(pass_code<=9999 && pass_code>=1000)
				{
				}
	           else
	           {
	        	   System.out.println("Pin must be four digit");
	        	   pin();
	           }
	           break;
	           }
			}
			catch(InputMismatchException e)
			{
				//handle the Arithmetic Exception
				System.out.println("Error use numbers not alphabets or any type of character");
			}		
	}
	
//******************************************************************Delete Customer*************************************************************
	/*public static void delCustomer() throws Exception
	{
	System.out.println("Enter Account Number to be Delete");
	Long ac = Long.parseLong(br.readLine());      //here we are checking all the objects stored in ArrayList by using iterating it its an inbuilt method
	Iterator it = arr.iterator();                 // Iterator checks the list one by one
		while(it.hasNext())                           // if arraylist have any object than || hasNext() checks the boolean Values
		{
			CreateAccount c = (CreateAccount)it.next();  
			if(ac == accno) 
			{
				String c_name = c.username; 
				arr.remove(c); // removed customer
				System.out.println("Customer " +ac+ "Removed Successfully");
				System.out.println("Mr./Ms. " +c_name+ " You are no longer associated with Naman Bank");
			}
		}
	}*/

}
