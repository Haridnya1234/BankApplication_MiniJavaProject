package bankApplication;
import java.util.Scanner;
public class DepositWithdraw
{
	static Scanner sc=new Scanner(System.in);
    static long accno=675456324132l;                                     //675456324132l this account number is common for every statement
	static int balance=100000;
	static int withdraw;
	static int deposit;
//********************************************Enter Details while you are Doing transaction*****************************************************
	static void accnoAndPass()
	{
		System.out.println("Enter Your Account number:- ");
		long accno1=sc.nextLong();
		System.out.println("Enter Your Pass Code:- ");
		int pass_code1=sc.nextInt();
		if(accno==accno1 && pass_code1==SimpleBankingApllication.passcode)
		{
			System.out.println();
		}
		else
		{
			System.out.println("You have entered Wrong Account number or Pass code");
		}
	}
//*******************************************************WITHDRAW AMOUNT METHOD*****************************************************************
	public static void withdrawAmmount()
	{
		System.out.println("Enter Your Account number:- ");
		long accno1=sc.nextLong();
		System.out.println("Enter Your Pass Code:- ");
		int pass_code1=sc.nextInt();
		if(accno==accno1 && pass_code1==SimpleBankingApllication.passcode)
		{
			System.out.println("Enter the amount you want to withdraw from your account");
			withdraw=sc.nextInt();
			if(balance>=withdraw)
			{
				balance=balance-withdraw;
				System.out.println(withdraw+"Rs amount is debited from your account.");
				System.out.println("Your account balance is:- "+balance+"Rs");
			}
			else
			{
				System.out.println("Insuffiecient Balance");
			}
		}
		else
		{
			System.out.println("You have entered Wrong Account number or Pass code");
		}
	}
	
//*******************************************************DEPOSITE AMOUNT METHOD****************************************************************

	public static void depositAmmount()
	{
		System.out.println("Enter Your Account number:- ");
		long accno1=sc.nextLong();
		System.out.println("Enter Your Pass Code:- ");
		int pass_code1=sc.nextInt();
		if(accno==accno1 && pass_code1==SimpleBankingApllication.passcode)
		{
			System.out.println("Enter the amount you want to deposit in your account");
			deposit=sc.nextInt();
					balance=balance+deposit;
			System.out.println(deposit+"Rs amount is credited in your account.");
			System.out.println("Your account balance is:- "+balance+"Rs");		
		}
		else
		{
			System.out.println("You have entered Wrong Account number or Pass code");
		}
	}

//********************************************************CHECK BALANCE METHOD******************************************************************

	public static void checkBalance()  //For checking balance of account
	{
		System.out.println("Enter Your Account number:- ");
		long accno1=sc.nextLong();
		System.out.println("Enter Your Pass Code:- ");
		int pass_code1=sc.nextInt();
		if(accno==accno1 && pass_code1==SimpleBankingApllication.passcode)
		{
			System.out.println("Hello "+SimpleBankingApllication.username);
			System.out.println("Your account Balance is:- "+balance+"Rs");
			System.out.println("Thank You For choosing us");
		}
		else
		{
			System.out.println("You have entered Wrong Account number or Pass code");
		}
	}
	
//*******************************************************TRANSFER MONEY METHOD*****************************************************************

	public static void transferMoney() 
	{
		System.out.println("Enter account number in which you want to transfer your money:- ");
		long transacc=sc.nextLong();
		System.out.println("Enter IFSC code:- ");
		String ifsc=sc.next();
		
	/*	try
			{
		System.out.println("Enter IFSC code:- ");
		String ifsc=sc.next();
		}
		catch(CaseSensitiveException e)
		{
			System.out.println("Your Can not use lower case for IFSC Code");

		} */
		System.out.println("Enter the amount you want to transfer:- ");
		int transamount=sc.nextInt();
		if(transamount<=balance)
		{
			System.out.println("Money sent succesfully");
			balance=transamount-balance;
			System.out.println("Your Account Balance is:- "+balance+"Rs");
		}
		else
		{
			System.out.println("You Dont have sufficient balance in your account");
		}	
	}
}
